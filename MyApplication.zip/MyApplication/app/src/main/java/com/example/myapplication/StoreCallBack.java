package com.example.myapplication;

public interface StoreCallBack {
    void startChooseDestination();
}
